class profesores:personas{

    public string departamento{get;set;}
    public profesores(string nombre, string apellidos, string cedula, string estadoC, string departamento):base(nombre, apellidos, cedula, estadoC){
     this.departamento=departamento;
     
    }
    public void Icambiode(){
        

        Console.WriteLine("Ingrese departamento al que fue cambiado: ");
        Console.WriteLine("Nuevo departamento: "+ Console.ReadLine());

    }

    public new void imprimir(){
        
        Console.WriteLine("Nombre: "+ nombre);
        Console.WriteLine("Apellidos: "+ apellidos);
        Console.WriteLine("Cédula: "+ cedula);
        Console.WriteLine("Estado civil: "+ estadoC);
        Console.WriteLine("Departamento al que pertenece: "+ departamento);
    }

}