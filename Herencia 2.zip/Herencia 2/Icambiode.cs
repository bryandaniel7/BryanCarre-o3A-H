interface Icambiode{
    public void cambiode();
}