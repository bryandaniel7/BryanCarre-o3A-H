class personas{
    public string nombre{get;set;}
    public string apellidos{get;set;}
    public string cedula{get;set;}
    public string estadoC{get;set;}

    public personas(string nombre, string apellidos, string cedula, string estadoC){
        this.nombre=nombre;
        this.apellidos=apellidos;
        this.cedula=cedula;
        this.estadoC=estadoC;

    }
    public void cambionEC(){
        Console.WriteLine("Ingrese el nuevo estado civil: ");
        Console.WriteLine("Nuevo estado civil: "+ Console.ReadLine());   
    }
    public void imprimir(){
        
        Console.WriteLine("Nombre: "+ nombre);
        Console.WriteLine("Apellidos: "+ apellidos);
        Console.WriteLine("Cédula: "+ cedula);
        Console.WriteLine("Estado civil: "+ estadoC);
    }

    


}