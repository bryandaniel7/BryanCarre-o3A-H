internal class Program
{
    private static void Main(string[] args)
    {
        
        
        

        
        empleados EM= new empleados("Kayla","Figueroa","1311647588","Soltera","2010","5");
        EM.imprimir();
        EM.cambionEC();
        EM.Icambiode();


        estudiantes E= new estudiantes("Kevin","pico","1311647588","Casado","3 A");
        E.imprimir();
        E.cambionEC();
        E.Icambiode();
        
        profesores P= new profesores("Drak","Pico","1311647588","Soltera","Lenguaje");
        P.imprimir();
        P.cambionEC();
        P.Icambiode();
        

        
        personalservicio PS= new personalservicio("Nuno","Pico","1311647588","Soltero","Biblioteca");
        PS.imprimir(); 
        PS.cambionEC();
        PS.Icambiode();
    }
}