class estudiantes:personas{

    public string curso{get;set;} 
    public estudiantes(string nombre, string apellidos, string cedula, string estadoC, string curso):base(nombre, apellidos, cedula, estadoC){
     this.curso=curso;
     
    }
    public void Icambiode(){

        Console.WriteLine("Ingrese el curso al que fue matriculado: ");
        Console.WriteLine("Nuevo curso al que fue matriculado: "+ Console.ReadLine());

    }

    public new void imprimir(){
        
        Console.WriteLine("Nombre: "+ nombre);
        Console.WriteLine("Apellidos: "+ apellidos);
        Console.WriteLine("Cédula: "+ cedula);
        Console.WriteLine("Estado civil: "+ estadoC);
        Console.WriteLine("Curso en el que está matriculado: "+ curso);
    }


}