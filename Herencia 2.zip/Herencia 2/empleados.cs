class empleados:personas{

    public string añoIC{get;set;}
    public string numeroD{get; set;}
    public empleados(string nombre, string apellidos, string cedula, string estadoC, string añoIC, string numeroD):base(nombre, apellidos, cedula, estadoC){
     this.añoIC=añoIC;
     this.numeroD=numeroD;
    }
    public void Icambiode(){
       

        Console.WriteLine("Ingrese el despacho al que fue reasignado: ");
        Console.WriteLine("Nuevo despacho: "+ Console.ReadLine());

    }

    public new void imprimir(){
        
        Console.WriteLine("Nombre: "+ nombre);
        Console.WriteLine("Apellidos: "+ apellidos);
        Console.WriteLine("Cédula: "+ cedula);
        Console.WriteLine("Estado civil: "+ estadoC);
        Console.WriteLine("Año de incorporación: "+ añoIC);
        Console.WriteLine("Número de despacho: "+ numeroD);
    }
}